package personas;
import java.util.*;

public class Estudiante {
	/*ATRIBUTOS*/
	public String nivelAlcanzado;
	public String fechaPrimerCurso;
	public String fechaUltimoCurso;
	
	/*MÉTODOS*/
	private Estudiante() {}
	private String getNivelAlcanzado() {
		return nivelAlcanzado;
	}
	private String getFechaPrimerCurso() {
		return fechaPrimerCurso;
	}
	private String getFechaUltimoCurso() {
		return fechaUltimoCurso;
	}
	private HashMap<String, LearningPath> getPathsCompletados() {}
	private HashMap<String, LearningPath> getPathsInscritos() {}
	private void inscribirPath(LearningPath path) {}
}
