package personas;

public abstract class Persona {
	/*ATRIBUTOS*/
	public String nombre;
	public String usuario;
	public String contrasenia;
	public String tipoUsuario;
	
	/*MÉTODOS*/
	private String getUsuario() {
		return usuario;
	}
	private String getTipoUsuario() {
		return tipoUsuario;
	}
	private void login(String usuario, String contrasenia) {}
}
