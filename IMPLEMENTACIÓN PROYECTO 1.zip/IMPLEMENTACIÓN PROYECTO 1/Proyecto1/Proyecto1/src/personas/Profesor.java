package personas;
import java.util.*;

public class Profesor {
	/*MÉTODOS*/
	private Profesor() {}
	private ArrayList<String> getListaEstudiantes() {}
	private ArrayList<LearningPath> getPathsCreados() {}
	private HashMap<String, LearningPath> getActividadesCreadas() {}
	private void crearPath(String titulo, String tiempoEstimado, ArrayList<Actividad> listaActividades) {}
	private void crearActividad(String titulo, String tipoActividad) {}
	private void calificar(Actividad actividad, String comentario, double calificacion, Estudiante estudiante) {}
}
