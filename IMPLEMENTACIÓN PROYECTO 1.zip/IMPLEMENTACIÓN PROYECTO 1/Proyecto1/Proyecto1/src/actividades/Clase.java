package actividades;
import java.util.*;

public class Clase {
	/*ATRIBUTOS*/
	public ArrayList<String> listaArchivos;
	public ArrayList<String> listaContenido;
	
	/*MÉTODOS*/
	private Clase() {}
	private void display() {} /*Falta poner void en el UML*/
	private ArrayList<String> getContenido() {
		return listaContenido;
	}
	private ArrayList<String> getArchivos() {
		return listaArchivos;
	}
}
