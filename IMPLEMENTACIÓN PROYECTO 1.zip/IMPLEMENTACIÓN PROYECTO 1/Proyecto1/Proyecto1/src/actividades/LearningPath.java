package actividades;

public class LearningPath {
	/*ATRIBUTOS*/
	public String titulo;
	public double progreso;
	public double rating;
	public String fechaCreacion;
	public String fechaModificacion;
	public String version;
	public String fechaFin;
	public String fechaInicio;
	public String tasaDeExito;
	public int tiempo;
	
	/*MÉTODOS*/
	private LearningPath() {}
	private String getTitulo() {
		return titulo;
	}
	private double getProgreso() {
		return progreso;
	}
	private String getFechaCreacion() {
		return fechaCreacion;
	}
	private String getFechaModificacion() {
		return fechaModificacion;
	}
	private String getVersion() {
		return version;
	}
	private String getFechaInicio() {
		return fechaInicio;
	}
	private String getFechaFin() {
		return fechaFin;
	}
	private String getTasaExito() {
		return tasaDeExito;
	}
	private int getTiempo() {
		return tiempo;
	}
	private void aniadirActividad(Actividad actividad) {}
	private void eliminarActividad(Actividad actividad) {}
}
