package actividades;

import java.util.ArrayList;

public class Quiz {
	/*ATRIBUTOS*/
	public ArrayList<String> listaPreguntas;
	public ArrayList<ArrayList<String>> listaOpciones;
	public ArrayList<String> listaRespuestaCorrecta;
	public ArrayList<String> listaRespuestaEstudiante;
	public double calificacion;
	public double calificacionAprobatoria;
	
	/*MÉTODOS*/
	private Quiz() {}
	private void display() {}
	private void responder(int numPregunta, String respuesta) {}
	private ArrayList<String> getRespuestas() {
		return listaRespuestaEstudiante;
	}
	private ArrayList<ArrayList<String>> getOpciones() {
		return listaOpciones;
	}
	private double getCalificacion() {
		return calificacion;
	}
	private boolean getAprobado() {
		if(calificacion >= calificacionAprobatoria) {
			return true;
		}
		else {
			return false;
		}
	}
}
