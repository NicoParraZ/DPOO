package actividades;
import java.util.*;

public class Encuesta {
	/*ATRIBUTOS*/
	public ArrayList<String> listaPreguntas;
	public ArrayList<String> listaRespuesta;
	public ArrayList<ArrayList<String>> listaOpciones;
	
	/*MÉTODOS*/
	private Encuesta() {}
	private void responder(int numPregunta, String respuesta) {}
	private void display() {}
	private ArrayList<String> getPreguntas() {
		return listaPreguntas;
	}
	private ArrayList<String> getOpciones() {
		return listaOpciones;
	} 
	private ArrayList<String> getRespuestas() {
		return listaRespuesta;
	}
	
}
