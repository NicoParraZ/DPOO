package actividades;
import java.util.*;

public class Examen {
	/*ATRIBUTOS*/
	public ArrayList<String> listaPreguntas;
	public boolean evaluado;
	public double calificacion;
	public ArrayList<String> listaRespuestas;
	public ArrayList<String> listaComentarios;
	
	/*MÉTODOS*/
	private Examen() {}
	private void responderPregunta(int numPregunta, String respuesta) {}
	private void calificar(int numPregunta, double calificacion, String comentario) {}
	private int getCalificacion() {
		return calificacion;
	}
	private ArrayList<String> getRespuestas() {
		return listaRespuestas;
	}
	private ArrayList<String> getPreguntas() {
		return listaPreguntas;
	}
	private ArrayList<String> getComentarios() {
		return listaComentarios;
	}
	private boolean getEvaluado() {
		return evaluado;
	}
	private void display() {}
}
