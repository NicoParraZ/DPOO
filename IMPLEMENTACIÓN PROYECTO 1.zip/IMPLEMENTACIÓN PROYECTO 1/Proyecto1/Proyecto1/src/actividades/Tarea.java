package actividades;
import java.util.*;

public class Tarea {
	/*ATRIBUTOS*/
	public ArrayList<String> listaInstrucciones;
	public boolean evaluado;
	public double calificacion;
	public String comentarios;
	
	/*MÉTODOS*/
	private Tarea() {}
	private void calificar(double calificacion, String comentarios) {} /*Error en UML, cambiar int por double*/
	private void display() {}
	private double getCalificacion() {
		return calificaion;
	}
	private String getComentarios() {
		return comentarios;
	}
	private ArrayList<String> getInstrucciones() {
		return listaInstrucciones;
	}
}
