package actividades;
import java.util.*;

public abstract class Actividad {
	/*ATRIBUTOS*/
	public String objetivo;
	public String tipoActividad;
	public String nivel;
	public String nombreActividad;
	public int tiempoEstimadoMinutos;
	public boolean completado;
	public ArrayList<Actividad> preRequisitosSugeridos;
	public String descripcion;
	public String fechaLimite;
	public double rating;
	public int tiempo;
	public String fechaInicio;
	public String fechaFin;
	public Actividad siguienteActividad;
	
	/*MÉTODOS*/
	private Actividad() {}
	private void display() {}
	private String getObjetivo() {
		return objetivo;
	}
	private String getTipoActividad() {
		return tipoActividad;
	}
	private String getNivel() {
		return nivel;
	}
	private String getNombre() {
		return nombreActividad;
	}
	private int getTiempoEstimado() {
		return tiempoEstimadoMinutos;
	}
	private boolean getCompletado() {
		return completado;
	}
	private ArrayList<Actividad> getPreRequisito() {
		return preRequisitosSugeridos;
	}
	private String getDescripcion() {
		return descripcion;
	}
	private String getFechaLimite() {
		return fechaLimite;
	}
	private double getRating() {
		return rating;
	}
	private int getTiempo() {
		return tiempo;
	}
	private String getFechaInicio() {
		return fechaInicio;
	}
	private String getFechaFin() {
		return fechaFin;
	}
	private Actividad getSiguienteActividad() {
		return siguienteActividad;
	}
}