package sistema;
import java.util.*;

public class Sistema {
	/*MÉTODOS*/
	private Sistema() {}
	private HashMap<String, Profesor> getMapaProfesores() {}
	private HashMap<String, Estudiante> getMapaEstudiantes() {}
	private HashMap<String, Actividad> getMapaActividadCreados() {}
	private HashMap<String, LearningPath> getMapaPathsCreados() {}
	private void aniadirActividad(Actividad actividad) {}
	private void aniadirPath(LearningPath path) {}
}
