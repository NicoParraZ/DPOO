package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;

public class ProductoAjustadoTest
{
	private ProductoMenu productoMenu;
	private ProductoAjustado productoAjustado;
	
	@BeforeEach
    void setUp( ) throws Exception
    {
		productoMenu = new ProductoMenu( "Hamburguesa", 10000 );
        productoAjustado = new ProductoAjustado( productoMenu );
    }

    @AfterEach
    void tearDown( ) throws Exception
    {
    }
    
    @Test
    void testGetNombre( )
    {
    	assertEquals( "Hamburguesa", productoMenu.getNombre( ), "El nombre no es el esperado." );
    }
    
    @Test
    public void testGenerarTextoFacturaConAjustes() {
        ProductoMenu base = new ProductoMenu("Hamburguesa con Queso", 16000);
        ProductoAjustado productoAjustado = new ProductoAjustado(base);

        Ingrediente cebolla = new Ingrediente("Cebolla", 500);
        Ingrediente tomate = new Ingrediente("Tomate", 300);

        productoAjustado.agregarIngrediente(cebolla);
        productoAjustado.eliminarIngrediente(tomate);

        String expectedFactura = "Hamburguesa con Queso\n"
                + "            16000\n"
                + "    +Cebolla                500    -Tomate            16500\n";
        assertEquals(expectedFactura, productoAjustado.generarTextoFactura());
    }
}