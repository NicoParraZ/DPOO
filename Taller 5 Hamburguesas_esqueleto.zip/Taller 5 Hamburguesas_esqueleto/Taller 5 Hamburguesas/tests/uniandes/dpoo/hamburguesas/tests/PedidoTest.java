package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class PedidoTest
{
	private Pedido pedido;
	
	@BeforeEach
    void setUp( ) throws Exception
    {
        pedido = new Pedido( "Cliente", "Direccion" );
    }

    @AfterEach
    void tearDown( ) throws Exception
    {
    }
    
    @Test
    void testGetNombreCliente( )
    {
    	assertEquals( "Cliente", pedido.getNombreCliente( ), "El nombre no es el esperado." );
    }
    
    @Test
    void testInicializacionPedido() {
        assertEquals("Cliente Test", pedido.getNombreCliente());
        assertEquals("Dirección Test", pedido.getDireccionCliente());
        assertEquals(3, pedido.getIdPedido());
    }

    @Test
    void testAgregarProducto() {
        ProductoMenu producto = new ProductoMenu("Hamburguesa Sencilla", 5000);
        pedido.agregarProducto(producto);
        
        assertEquals(1, pedido.getProductos().size());
        assertTrue(pedido.getProductos().contains(producto));
    }
}