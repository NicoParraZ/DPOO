package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest
{
	private Combo combo;
	ArrayList<ProductoMenu> items = new ArrayList<>();
	
	@BeforeEach
    void setUp( ) throws Exception
    {
		combo = new Combo( "SuperCombo", 0.2, items );
    }

    @AfterEach
    void tearDown( ) throws Exception
    {
    }
    
    @Test
    void testGetNombre( )
    {
    	assertEquals( "SuperCombo", combo.getNombre( ), "El nombre no es el esperado." );
    }
    
    @Test
    void testGetPrecio( )
    {
    	ProductoMenu producto1 = new ProductoMenu("Hamburguesa", 15000);
        ProductoMenu producto2 = new ProductoMenu("Papas", 5000);
        items.add(producto1);
        items.add(producto2);
        combo = new Combo( "SuperCombo", 0.2, items );
        int precio = (15000+5000)*(int)0.2;
        
    	assertEquals( precio, combo.getPrecio( ), "El precio no es el esperado." );
    }
    
    void testGenerarTextoFactura( )
    {
    	assertEquals( "Combo " + "SuperCombo" + "\n" + " Descuento: " + 0.2 + "\n" + "            " + combo.getPrecio() + "\n", combo.generarTextoFactura(), "La factura no es la esperada." );
    }
}