package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.*;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
import uniandes.dpoo.aerolinea.modelo.Vuelo;

public abstract class Cliente
{
	private List<Tiquete> tiquetesUsados;
	
	private List<Tiquete> tiquetesSinUsar;
	
	public Cliente(){};
	
	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	public void agregarTiquete(Tiquete tiquete)
	{
		tiquetesSinUsar.add(tiquete);
	}
	
	public int calcularValorTiquetes()
	{
		int total = 0;
		
		for(Tiquete tiquete : tiquetesSinUsar)
		{
			total += tiquete.getTarifa();
		}
		
		return total;
	}
	
	public void usarTiquetes(Vuelo vuelo)
	{
		for(Tiquete tiquete : tiquetesSinUsar)
		{
			tiquete.marcarComoUsado();
			
			tiquetesUsados.add(tiquete);
			
			tiquetesSinUsar.remove(tiquete);
		}
	}

}