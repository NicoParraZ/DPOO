package uniandes.dpoo.aerolinea.modelo;

import java.util.*;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo
{
	Ruta ruta = getRuta();
	
	private String fecha;
	
	Avion avion = getAvion();
	
	Collection<Tiquete> tiquetes = getTiquetes();
	
	public Vuelo(Ruta ruta, String fecha, Avion avion)
	{
		this.ruta = ruta;
		
		this.fecha = fecha;
		
		this.avion = avion;
	}
	
	public Ruta getRuta()
	{
		return ruta;
	}
	
	public String getFecha()
	{
		return fecha;
	}
	
	public Avion getAvion()
	{
		return avion;
	}
	
	public Collection<Tiquete> getTiquetes()
	{
		return tiquetes;
	}
	
	//No sé como hacer las últimas dos funciones.
}